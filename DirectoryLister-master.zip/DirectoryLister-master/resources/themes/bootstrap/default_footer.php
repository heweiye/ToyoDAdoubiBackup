<footer class="container">
  <div class="footer">
 © 2015-<?php echo date("Y")?> <a href="https://doub.io" target="_blank">逗比根据地</a> . All rights reserved.
   </div>
</footer>
